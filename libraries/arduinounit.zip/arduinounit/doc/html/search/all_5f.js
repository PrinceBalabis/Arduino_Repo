var searchData=
[
  ['_5f_5ffreelist',['__freelist',['../struct____freelist.html',1,'']]]
];
