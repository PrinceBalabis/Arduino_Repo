var searchData=
[
  ['config',['config',['../class_digital_pin.html#ac08cb2fcdac8a690b3392c9d5b144962',1,'DigitalPin::config()'],['../group__runtime_digital.html#ga6074521767525ecbc51f2c0e2433ef87',1,'PinIO::config()']]]
];
