var searchData=
[
  ['miso_5flevel',['MISO_LEVEL',['../group__soft_s_p_i.html#ga5ed39ec843c7f42ec220a59c0b486718',1,'SoftSPI.h']]],
  ['miso_5fmode',['MISO_MODE',['../group__soft_s_p_i.html#gad7667379ccd35490d35bb159b1492ea2',1,'SoftSPI.h']]],
  ['mosi_5fmode',['MOSI_MODE',['../group__soft_s_p_i.html#gadfe834b166b0ff6be3271f17420e72ec',1,'SoftSPI.h']]]
];
