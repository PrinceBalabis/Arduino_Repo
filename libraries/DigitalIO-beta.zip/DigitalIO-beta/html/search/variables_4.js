var searchData=
[
  ['pin',['pin',['../structpin__map__t.html#a42b51799010669a8ac2b964843afbfcf',1,'pin_map_t']]],
  ['port',['port',['../structpin__map__t.html#a08f4c39a3cbb329c79b88f819dd7975f',1,'pin_map_t']]]
];
