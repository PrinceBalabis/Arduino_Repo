var searchData=
[
  ['software_20i2c',['Software I2C',['../group__soft_i2_c.html',1,'']]],
  ['software_20spi',['Software SPI',['../group__soft_s_p_i.html',1,'']]]
];
